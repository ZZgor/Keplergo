#!/usr/bin/env bash
# End-to-end check of the safety net with fake nvidia tools. No GPU is touched.
# usage: bash tests/smoke.sh   (from the project directory, Go installed)
set -u
root="$(cd "$(dirname "$0")/.." && pwd)"
work="$(mktemp -d)"
export FAKE_DIR="$work/fake" KEPLERGO_STATE_DIR="$work/state"
mkdir -p "$FAKE_DIR"
export PATH="$root/tests/fakebin:$PATH"
unset DISPLAY XAUTHORITY XDG_SESSION_TYPE WAYLAND_DISPLAY
(cd "$root" && go build -o "$work/keplergo" .) || exit 1
bin="$work/keplergo"
fail=0

gfx() { cat "$FAKE_DIR/GPUGraphicsClockOffset.3" 2>/dev/null || echo 0; }
mem() { cat "$FAKE_DIR/GPUMemoryTransferRateOffset.3" 2>/dev/null || echo 0; }
watchdogs() { pgrep -f "$bin -i 0 watchdog" | wc -l; }
expect() { # name, got, want
  if [ "$2" = "$3" ]; then echo "  ok    $1"; else echo "  FAIL  $1 (got '$2', want '$3')"; fail=1; fi
}
cleanup() { pkill -f "$bin -i 0 watchdog" 2>/dev/null; pkill -f "sleep 60" 2>/dev/null; rm -rf "$work"; }
trap cleanup EXIT

echo "A: confirmed overclock stays, otval restores"
(sleep 3; echo) | timeout 30 "$bin" oc -gfx 50 -mem 100 -window 8s > "$work/a.log" 2>&1
expect "oc exit code" "$?" "0"
expect "core offset applied" "$(gfx)" "50"
expect "memory offset applied" "$(mem)" "100"
expect "watchdog keeps running" "$(watchdogs)" "1"
timeout 30 "$bin" otval > "$work/a2.log" 2>&1
expect "otval exit code" "$?" "0"
expect "core offset restored" "$(gfx)" "0"
expect "memory offset restored" "$(mem)" "0"
sleep 1
expect "watchdog stopped" "$(watchdogs)" "0"
expect "session removed" "$(ls "$KEPLERGO_STATE_DIR"/session.json 2>/dev/null | wc -l)" "0"

echo "B: no confirmation restores by itself (black screen case)"
sleep 60 | timeout 30 "$bin" oc -gfx 60 -mem 120 -window 5s > "$work/b.log" 2>&1
expect "oc exit code" "$?" "3"
expect "core offset restored" "$(gfx)" "0"
expect "memory offset restored" "$(mem)" "0"
sleep 1
expect "watchdog stopped" "$(watchdogs)" "0"

echo "C: the shell dies right after applying, the watchdog still restores"
( sleep 60 | "$bin" oc -gfx 70 -mem 130 -window 5s > "$work/c.log" 2>&1 ) &
sleep 2
expect "offset is applied" "$(gfx)" "70"
pkill -9 -f "$bin oc"
sleep 11
expect "core offset restored by the watchdog" "$(gfx)" "0"
expect "memory offset restored by the watchdog" "$(mem)" "0"
expect "session removed" "$(ls "$KEPLERGO_STATE_DIR"/session.json 2>/dev/null | wc -l)" "0"

echo "D: overheating after confirmation"
(sleep 3; echo) | timeout 30 "$bin" oc -gfx 40 -mem 80 -window 8s > "$work/d.log" 2>&1
expect "applied and kept" "$(gfx)" "40"
echo 95 > "$FAKE_DIR/temp"
sleep 6
expect "core offset restored on heat" "$(gfx)" "0"
expect "event logged" "$(grep -c 'temperature 95 C' "$KEPLERGO_STATE_DIR/events.log")" "1"
echo 50 > "$FAKE_DIR/temp"

echo "E: X server down during otval, then back"
(sleep 3; echo) | timeout 30 "$bin" oc -gfx 30 -mem 60 -window 8s > "$work/e.log" 2>&1
touch "$FAKE_DIR/xdown"
timeout 60 "$bin" otval > "$work/e2.log" 2>&1
expect "otval reports failure" "$?" "1"
grep -q "ctrl+alt+f3\|Ctrl+Alt+F3" "$work/e2.log"
expect "recovery hint shown" "$?" "0"
rm "$FAKE_DIR/xdown"
sleep 6
expect "watchdog finished the job" "$(gfx)" "0"

echo "F: limits and debug"
"$bin" oc -gfx 500 > "$work/f.log" 2>&1
expect "oversized offset rejected" "$?" "2"
"$bin" debug > "$work/f2.log" 2>&1
expect "debug exit code" "$?" "0"
grep -q "last 20 events" "$work/f2.log"
expect "debug lists events" "$?" "0"

echo
if [ "$fail" = 0 ]; then echo "all checks passed"; else echo "SOME CHECKS FAILED"; fi
exit "$fail"
